package com.javalec.ex.DAO;

import java.sql.*;
import java.util.*;
import javax.naming.*;
import javax.sql.DataSource;

import com.javalec.ex.DTO.MemberDTO;

public class MemberDAO {
	private Connection conn=null;
	private Statement st = null;
	private ResultSet rs= null;
	private PreparedStatement ps=null;
	
	private DataSource ds=null;
	
	public MemberDAO() {
		try {
			//jdbc 드라버 로드
			Context ctx= new InitialContext();
			ds = (DataSource)ctx.lookup("java:comp/env/jdbc/mysql");	// 생성자
		}catch(Exception e) {
			System.out.println("MemberDAO 생성자 에러");
			e.printStackTrace();
		}
	}
	public void MemberInsert(String id, String pw, String name, String address, String phone_num, String email, String since) {
		conn=null;
		ps=null;
		try {
			// DB 접속
			conn = ds.getConnection();
			//INSERT 구문 수행
			String query="insert into member values(?,?,?,?,?,?,?)";
			ps=conn.prepareStatement(query);
			ps.setString(1, id);
			ps.setString(2, pw);
			ps.setString(3, name);
			ps.setString(3, address);
			ps.setString(3, phone_num);
			ps.setString(3, email);
			ps.setString(3, since);
			ps.executeUpdate();
		}catch(Exception e) {
			System.out.println("Insert 쿼리 실패");
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				conn.close();
			}catch(Exception e1) {
				System.out.println("객체 닫기 실패");
				e1.printStackTrace();
			}
		}
	}
}
	