package com.javalec.ex.command;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.javalec.ex.DAO.MemberDAO;
import com.javalec.ex.DTO.MemberDTO;

public class MemberSerInsert implements MemberSer {
	public ArrayList<MemberDTO> execute(HttpServletRequest request, HttpServletResponse response){
		ArrayList<MemberDTO> dto=null;
		
		//DAO에 있는 insert 메소드만 수행
		MemberDAO dao= new MemberDAO();
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String name = request.getParameter("name");
		String address = request.getParameter("address");
		String phone_num = request.getParameter("phone_num");
		String email = request.getParameter("email");
		String since = request.getParameter("since");
		
		dao.MemberInsert(id,pw,name,address,phone_num,email,since);
		
		return dto;
	}
}
